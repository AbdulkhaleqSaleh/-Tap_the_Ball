Game: Tap the Ball (Dart & Flutter)
Instructions:
- Tap the ball to gain points.
- Each tap moves the ball to a random position.

Run:
flutter pub get
flutter run
